import pyAesCrypt
from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter import messagebox

root = Tk()
root.title('SecretX By Rauf v1.0')
root.geometry("485x315")
root.resizable(height = 0, width = 0)
root.configure(bg='#dbdbdb')


def buka_file():
    global letak
    fileName = askopenfilename(parent=root, title='Pilih File')
    file = Label(root, text=fileName)
    file.pack()
    file.place(x=150, y=25)
    letak = file.cget("text")
    
    
mylabel3=Label(root, text="Pilih file yang akan dilakukan encrypt atau decrypt", wraplength=250, justify=LEFT, bg='#dbdbdb')
mylabel3.pack()
mylabel3.place(x=25)
browse = Button(root, text="Pilih File", command=buka_file)
browse.pack()
browse.place(x=25, y=40)



mylabel2=Label(root, text="Nama File Baru", justify=LEFT, bg='#dbdbdb')
mylabel2.pack()
mylabel2.place(x=25, y=60)

f = Entry(root, width=30, bg='#dbdbdb')
f.pack()
f.place(x=175, y=55)

mylabel=Label(root, text="Password", bg='#dbdbdb')
mylabel.pack()
mylabel.place(x=25, y=100)

e = Entry(root, width=30, bg='#dbdbdb')
e.pack()
e.place(x=175, y=95)


try:
    letak
except NameError:
    letak = None

def popup_enkripsi():
    messagebox.showinfo("Enkripsi status", "Enkripsi berhasil")

def popup_enkripsi_error():
    messagebox.showwarning("Enkripsi status", "File belum dipilih")

def popup_dekrip():
    messagebox.showinfo("Dekrip status", "Dekrip sukses")

def popup_dekrip_error():
    messagebox.showwarning("Dekrip status", "File belum dipilih")

def myDecrypt():

    bufferSize = 256 * 1024
    password=e.get()
    
    pyAesCrypt.decryptFile(letak, f.get(), password, bufferSize)

def myEncrypt():
    bufferSize = 256 * 1024
    password=e.get()
    pyAesCrypt.encryptFile(letak, f.get(), password, bufferSize)
    
def enkripsi():
    if letak is None:
        popup_enkripsi_error()
    else:
        myEncrypt()
        popup_enkripsi()

def dekrip():
    if letak is None:
        popup_dekrip_error()
    else:
        myDecrypt()
        popup_dekrip()


myButton = Button(root, text="Encrypt", width=10, command=enkripsi)
myButton.pack()
myButton.place(x=45, y=150)



myButton2 = Button(root, text="Decrypt", width=10, command=dekrip)
myButton2.pack()
myButton2.place(x=150, y=150)

mylabel4=Label(root, text="Catatan : Pastikan anda mengingat format file yang di encrypt atau decrypt atau anda dapat menyertakan format file pada nama file", wraplength=250, justify=LEFT)
mylabel4.pack()
mylabel4.place(x=25, y=200)

mylabel5=Label(root, text="https://www.facebook.com/rauf.endro/", bg='#dbdbdb')
mylabel5.pack()
mylabel5.place(x=25, y=280)
    

root.mainloop()

